<?php
session_start();

session_unset();
session_destroy();

// Evita que a página anterior apareça no botão voltar
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

header("Location:login.php");
exit();
?>
