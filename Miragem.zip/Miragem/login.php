<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="auth.css">
    <title>Login — Miragem Mood</title>
</head>

<body>

    
    <div class="bg-animations">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </div>

    <div class="container">
        <h2>Entrar na Miragem</h2>

        <form id="loginForm">

            <div class="input-group">
                <label>Email</label>
                <input type="email" id="emailLogin" required>
               
                <svg class="icon" viewBox="0 0 24 24" fill="none">
                    <rect x="3" y="5" width="18" height="14" rx="2" stroke="white" stroke-width="1.8"/>
                    <path d="M3 7l9 6 9-6" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </div>

            <div class="input-group">
                <label>Senha</label>
                <input type="password" id="passwordLogin" required>
              
                <svg class="icon" viewBox="0 0 24 24" fill="none">
                    <rect x="4" y="10" width="16" height="11" rx="2" stroke="white" stroke-width="1.8"/>
                    <path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                    <circle cx="12" cy="16" r="1.5" fill="white"/>
                </svg>
            </div>

            <button type="submit">Entrar</button>

            <p id="loginMessage"></p>

            <p class="switch">
                Ainda não tem conta?  
                <a href="registro.php">Criar conta</a>
            </p>
        </form>

    </div>

</body>
<script>
    // ============================
// LOGIN
// ============================
document.getElementById("loginForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("emailLogin").value.trim();
    const password = document.getElementById("passwordLogin").value.trim();
    const msg = document.getElementById("loginMessage");

    // ===== Validações =====
    if (!email || !password) {
        msg.textContent = "Preencha todos os campos.";
        msg.style.color = "red";
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        msg.textContent = "Email inválido.";
        msg.style.color = "red";
        return;
    }

    // ===== Envio via Fetch =====
    try {
        const res = await fetch("auth.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (data.status) {
            msg.style.color = "green";
            msg.textContent = "Login efetuado! Redirecionando…";

            setTimeout(() => {
                window.location.href = "dashboard.php";
            }, 1200);

        } else {
            msg.style.color = "red";
            msg.textContent = data.msg;
        }

    } catch (error) {
        msg.textContent = "Erro ao conectar ao servidor.";
        msg.style.color = "red";
    }
});

</script>
</html>
