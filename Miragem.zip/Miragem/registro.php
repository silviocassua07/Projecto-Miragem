<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="auth.css">
    <title>Criar Conta — Miragem Mood</title>
</head>

<body>

  
    <div class="bg-animations">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </div>

    <div class="container">
        <h2>Criar Conta</h2>

        <form id="registerForm">

            <div class="input-group">
                <label>Nome Completo</label>
                <input type="text" id="name" required>
                
                <svg class="icon" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="7" r="5" stroke="white" stroke-width="1.8"/>
                    <path d="M4 21c0-4 4-7 8-7s8 3 8 7" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </div>

            <div class="input-group">
                <label>Email</label>
                <input type="email" id="email" required>
                <!-- SVG Email -->
                <svg class="icon" viewBox="0 0 24 24" fill="none">
                    <rect x="3" y="5" width="18" height="14" rx="2" stroke="white" stroke-width="1.8"/>
                    <path d="M3 7l9 6 9-6" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </div>

            <div class="input-group">
                <label>Senha</label>
                <input type="password" id="password" required>
                <!-- SVG Lock -->
                <svg class="icon" viewBox="0 0 24 24" fill="none">
                    <rect x="4" y="10" width="16" height="11" rx="2" stroke="white" stroke-width="1.8"/>
                    <path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                    <circle cx="12" cy="16" r="1.5" fill="white"/>
                </svg>
            </div>

            <div class="input-group">
                <label>Confirmar Senha</label>
                <input type="password" id="confirm" required>
                <!-- SVG Lock -->
                <svg class="icon" viewBox="0 0 24 24" fill="none">
                    <rect x="4" y="10" width="16" height="11" rx="2" stroke="white" stroke-width="1.8"/>
                    <path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                    <circle cx="12" cy="16" r="1.5" fill="white"/>
                </svg>
            </div>
            <button type="submit">Criar Conta</button>

            <p id="message"></p>

            <p class="switch">
                Já tem conta?  
                <a href="login.html">Entrar</a>
            </p>
        </form>

    </div>

</body>
<script>
    document.getElementById("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const pass = document.getElementById("password").value.trim();
    const confirm = document.getElementById("confirm").value.trim();
    const msgBox = document.getElementById("message");

    // ===== Validações antes de enviar =====

    if (!name || !email || !pass || !confirm) {
        msgBox.textContent = "Preencha todos os campos.";
        msgBox.style.color = "red";
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        msgBox.textContent = "Email inválido.";
        msgBox.style.color = "red";
        return;
    }

    if (pass.length < 6) {
        msgBox.textContent = "A senha deve ter pelo menos 6 caracteres.";
        msgBox.style.color = "red";
        return;
    }

    if (pass !== confirm) {
        msgBox.textContent = "As senhas não coincidem.";
        msgBox.style.color = "red";
        return;
    }

    // ==============================
    // Enviar via fetch
    // ==============================

    try {
        const response = await fetch("processa_registro.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password: pass })
        });

        const data = await response.json();

        if (data.status) {
            msgBox.style.color = "green";
            msgBox.textContent = "Conta criada! Redirecionando…";
            window.href = "dashboard.php"

            setTimeout(() => {
                window.location.href = "dashboard.php";
            }, 1500);

        } else {
            msgBox.style.color = "red";
            msgBox.textContent = data.msg;
        }

    } catch (err) {
        msgBox.textContent = "Erro ao conectar ao servidor.";
        msgBox.style.color = "red";
    }
});

</script>
</html>
