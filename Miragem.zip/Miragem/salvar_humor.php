<?php
session_start();
require_once "db.php";
header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$mood = trim($data['mood'] ?? '');

if (!$mood) {
    echo json_encode(["success" => false]);
    exit;
}

$stmt = $conn->prepare("UPDATE users SET mood = ? WHERE id = ?");
$stmt->bind_param("si", $mood, $_SESSION['user_id']);
$stmt->execute();

echo json_encode(["success" => true]);
