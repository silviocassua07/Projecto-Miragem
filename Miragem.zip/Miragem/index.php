<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIRAGEM — Página Inicial</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

   <header class="hero">
    <nav class="top-bar">
    <a href="login.php" class="btn-login">Login</a>
</nav>

    <div class="hero-content">
        <h1 class="miragem-anim">MIRAGEM</h1>
        <p>Transforme sua jornada digital com uma interface que entende seu humor, seu ritmo e seu estilo. 
            O MIRAGEM é mais que um site  é uma experiência emocional e visual totalmente personalizada.</p>
        <p>Descubra temas dinâmicos, registre seu humor, acompanhe seu histórico e mergulhe numa plataforma criada para evoluir com você.</p>
    </div>
</header>

    <section class="features">
        <h2>O que você encontra no MIRAGEM</h2>

        <div class="cards">
            <div class="card">
                <h3>🎭 Personalização Emocional</h3>
                <p>Seu humor influencia a interface. Cores, animações e estilos mudam conforme seu estado emocional.</p>
            </div>

            <div class="card">
                <h3>🎨 Temas Inteligentes</h3>
                <p>Escolha manualmente ou deixe o sistema selecionar automaticamente o tema ideal para você.</p>
            </div>

            <div class="card">
                <h3>📊 Evolução do Humor</h3>
                <p>Acompanhe seu progresso emocional através de gráficos e um histórico completo.</p>
            </div>

            <div class="card">
                <h3>⚡ Interface Moderna</h3>
                <p>Animações suaves, layout fluido e UX focada no utilizador.</p>
            </div>

            <div class="card">
                <h3>📱 100% Responsivo</h3>
                <p>Funciona perfeitamente em qualquer dispositivo.</p>
            </div>

            <div class="card">
                <h3>🌟 Experiência Única</h3>
                <p>Cada pessoa vivencia o MIRAGEM de uma forma diferente. Aqui você é o centro.</p>
            </div>

            <div class="card">
                <h3>🔔 Sistema de Eventos</h3>
                <p>O site aprende com as suas ações para melhorar constantemente a experiência.</p>
            </div>

            <div class="card">
                <h3>🛡️ Segurança</h3>
                <p>Autenticação segura e dados protegidos.</p>
            </div>
        </div>
    </section>

    <footer>
        MIRAGEM © 2025 — A experiência digital que acompanha você.
    </footer>

</body>
</html>
