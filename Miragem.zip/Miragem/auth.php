<?php
session_start();
header("Content-Type: application/json");

include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if (!$email || !$password) {
    echo json_encode(["status" => false, "msg" => "Preencha todos os campos."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => false, "msg" => "Email inválido."]);
    exit;
}

// Buscar usuário + mood
$stmt = $conn->prepare("
    SELECT id, name, password, mood 
    FROM users 
    WHERE email = ?
");

if (!$stmt) {
    echo json_encode(["status" => false, "msg" => "Erro na consulta."]);
    exit;
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => false, "msg" => "Email não encontrado."]);
    exit;
}

$user = $result->fetch_assoc();

// Verificar senha
if (!password_verify($password, $user['password'])) {
    echo json_encode(["status" => false, "msg" => "Senha incorreta."]);
    exit;
}

// Sessão
$_SESSION["user_id"] = $user["id"];
$_SESSION["user_name"] = $user["name"];
$_SESSION["user_email"] = $email;
$_SESSION["user_mood"] = $user["mood"]; // ⭐ FUNDAMENTAL

echo json_encode([
    "status" => true,
    "msg" => "Login realizado com sucesso."
]);
