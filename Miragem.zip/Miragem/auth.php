<?php
session_start();
header("Content-Type: application/json");

include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data['email']);
$password = trim($data['password']);

if (!$email || !$password) {
    echo json_encode(["status" => false, "msg" => "Preencha todos os campos."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => false, "msg" => "Email inválido."]);
    exit;
}

// Buscar usuário
$stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => false, "msg" => "Email não encontrado."]);
    exit;
}

$user = $result->fetch_assoc();

// Verificar senha
if (!password_verify($password, $user['password'])) {
    echo json_encode(["status" => false, "msg" => "Senha incorreta."]);
    exit;
}

// Criar sessão
$_SESSION["user_id"] = $user["id"];
$_SESSION["user_name"] = $user["name"];
// Criar sessão
$_SESSION["user_id"] = $user["id"];
$_SESSION["user_name"] = $user["name"];
$_SESSION["user_email"] = $email;

echo json_encode(["status" => true, "msg" => "Login realizado com sucesso."]);
?>
