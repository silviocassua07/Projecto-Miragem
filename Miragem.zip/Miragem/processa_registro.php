<?php
session_start();
header("Content-Type: application/json");

include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$name = trim($data['name']);
$email = trim($data['email']);
$password = trim($data['password']);

// ===== Validações =====

if (!$name || !$email || !$password) {
    echo json_encode(["status" => false, "msg" => "Preencha todos os campos."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => false, "msg" => "Email inválido."]);
    exit;
}

// Verificar email único
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["status" => false, "msg" => "Este email já está cadastrado."]);
    exit;
}

// Hash da senha
$hashed = password_hash($password, PASSWORD_DEFAULT);

// Inserir usuário
$stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $hashed);

if ($stmt->execute()) {
    $_SESSION["user_id"] = $stmt->insert_id;
    $_SESSION["user_name"] = $name;
    $_SESSION["user_email"] = $email;

    echo json_encode(["status" => true, "msg" => "Conta criada com sucesso!"]);
} else {
    echo json_encode(["status" => false, "msg" => "Erro ao criar conta."]);
}
?>
