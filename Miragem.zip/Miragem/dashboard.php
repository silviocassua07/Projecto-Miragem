

<?php
session_start();

// SE O USUARIO NÃO ESTIVER LOGADO, REDIRECIONA
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Informações do usuário
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email']; // <- capturado do login
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MIRAGEM — Dashboard</title>
<link rel="stylesheet" href="dashboard.css">
</head>
<body>

<!-- ========================= NAVBAR ========================= -->
<nav class="navbar">
    <div class="nav-left">
        <h2 class="site-title">MIRAGEM</h2>
    </div>

    <div class="nav-right">
        <div class="user-info">
            <svg class="avatar" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#8F41F8"/>
                <circle cx="12" cy="10" r="3" fill="#fff"/>
                <path d="M6 18c1-3 4-4 6-4s5 1 6 4" fill="#fff"/>
            </svg>

            <span class="user-name"><?php echo htmlspecialchars($user_name); ?></span>
        </div>

        <a href="logout.php" class="logout-btn">Sair</a>
    </div>
</nav>

<!-- MODAL DE PERFIL -->
<div id="profileModal" class="modal">
  <div class="modal-content">
    <h2 class="modal-title">MIRAGEM  - Editar o Perfil</h2>
    
    <form id="profileForm">
      <div class="form-group">
        <label for="name">Nome</label>
        <input type="text" id="name" name="name" placeholder="Digite seu nome" value="<?php echo htmlspecialchars($user_name); ?>" required>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Digite seu email" value="<?php echo htmlspecialchars($user_email); ?>" required>
      </div>

      <div class="form-group">
        <label for="newPassword">Nova Senha</label>
        <input type="password" id="newPassword" name="newPassword" placeholder="Digite nova senha">
      </div>

      <div class="form-group">
        <label for="confirmPassword">Confirmar Nova Senha</label>
        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirme a nova senha">
      </div>

      <div class="form-message" id="formMessage"></div>

      <div class="modal-buttons">
    <button type="submit" class="btn-save">Salvar Alterações</button>
    <button type="button" id="closeModalBtn" class="btn-close">Fechar</button>
</div>

    </form>
  </div>
</div>





<!-- ========================= CONTEÚDO ========================= -->
<div class="container">

    <h1 class="title">Como você está se sentindo hoje?</h1>
    <p class="subtitle">Escolha um dos 15 estados emocionais — o MIRAGEM adapta-se a você.</p>

    <div class="mood-selector">

    <!-- 1. Feliz -->
    <div class="mood-item" data-mood="Feliz">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#FFD93D"/>
                <circle cx="8" cy="10" r="1.5" fill="#000"/>
                <circle cx="16" cy="10" r="1.5" fill="#000"/>
                <path d="M8 15c1.5 2 4.5 2 6 0" stroke="#000" stroke-width="2" fill="none"/>
            </svg>
        </div>
        <span>Feliz</span>
    </div>

    <!-- 2. Neutro -->
    <div class="mood-item" data-mood="Neutro">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#CCCCCC"/>
                <circle cx="8" cy="10" r="1.5" fill="#000"/>
                <circle cx="16" cy="10" r="1.5" fill="#000"/>
                <line x1="8" y1="15" x2="16" y2="15" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Neutro</span>
    </div>

    <!-- 3. Triste -->
    <div class="mood-item" data-mood="Triste">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#7DB2FF"/>
                <circle cx="8" cy="10" r="1.5" fill="#000"/>
                <circle cx="16" cy="10" r="1.5" fill="#000"/>
                <path d="M16 16c-2-2 -4 -2 -6 0" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Triste</span>
    </div>

    <!-- 4. Zangado -->
    <div class="mood-item" data-mood="Zangado">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#FF5A5A"/>
                <path d="M7 9l2-2M17 9l-2-2" stroke="#000" stroke-width="2"/>
                <circle cx="8" cy="11" r="1.4" fill="#000"/>
                <circle cx="16" cy="11" r="1.4" fill="#000"/>
                <path d="M8 16c2 -1 6 -1 8 0" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Zangado</span>
    </div>

    <!-- 5. Apaixonado -->
    <div class="mood-item" data-mood="Apaixonado">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#FF78C2"/>
                <path d="M12 17s4-2.5 4-5 -4 -3 -4 -1 -4 -1 -4 1 4 5 4 5z" fill="#fff"/>
            </svg>
        </div>
        <span>Apaixonado</span>
    </div>

    <!-- 6. Ansioso -->
    <div class="mood-item" data-mood="Ansioso">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#9B5DE5"/>
                <circle cx="8" cy="10" r="1.3" fill="#fff"/>
                <circle cx="16" cy="10" r="1.3" fill="#fff"/>
                <line x1="8" y1="17" x2="16" y2="17" stroke="#fff" stroke-width="2"/>
            </svg>
        </div>
        <span>Ansioso</span>
    </div>

    <!-- 7. Cansado -->
    <div class="mood-item" data-mood="Cansado">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#A8A8A8"/>
                <path d="M7 10h3M14 10h3" stroke="#000" stroke-width="2"/>
                <path d="M8 16c2 -1 4 -1 6 0" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Cansado</span>
    </div>

    <!-- 8. Estressado -->
    <div class="mood-item" data-mood="Estressado">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#FF914D"/>
                <path d="M7 9l2-1M15 8l2 1" stroke="#000" stroke-width="2"/>
                <line x1="8" y1="15" x2="16" y2="15" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Estressado</span>
    </div>

    <!-- 9. Surpreso -->
    <div class="mood-item" data-mood="Surpreso">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#FFE467"/>
                <circle cx="8" cy="10" r="1.4" fill="#000"/>
                <circle cx="16" cy="10" r="1.4" fill="#000"/>
                <circle cx="12" cy="16" r="2" fill="#000"/>
            </svg>
        </div>
        <span>Surpreso</span>
    </div>

    <!-- 10. Motivado -->
    <div class="mood-item" data-mood="Motivado">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#00C896"/>
                <path d="M8 14c2 2 6 2 8 0" stroke="#000" stroke-width="2"/>
                <circle cx="8" cy="10" r="1.4" fill="#000"/>
                <circle cx="16" cy="10" r="1.4" fill="#000"/>
            </svg>
        </div>
        <span>Motivado</span>
    </div>

    <!-- 11. Confuso -->
    <div class="mood-item" data-mood="Confuso">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#7FD4FF"/>
                <circle cx="8" cy="10" r="1.4" fill="#000"/>
                <circle cx="16" cy="10" r="1.4" fill="#000"/>
                <path d="M8 17h5c2 0 3 -1 3 -2" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Confuso</span>
    </div>

    <!-- 12. Doente -->
    <div class="mood-item" data-mood="Doente">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#A4DFF0"/>
                <circle cx="8" cy="10" r="1.2" fill="#000"/>
                <circle cx="16" cy="10" r="1.2" fill="#000"/>
                <path d="M8 16h8" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Doente</span>
    </div>

    <!-- 13. Calmo -->
    <div class="mood-item" data-mood="Calmo">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#6EE7B7"/>
                <circle cx="8" cy="10" r="1.4" fill="#000"/>
                <circle cx="16" cy="10" r="1.4" fill="#000"/>
                <path d="M8 15c2 1 4 1 8 0" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Calmo</span>
    </div>

    <!-- 14. Empolgado -->
    <div class="mood-item" data-mood="Empolgado">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#FFB84D"/>
                <circle cx="8" cy="10" r="1.5" fill="#000"/>
                <circle cx="16" cy="10" r="1.5" fill="#000"/>
                <path d="M7 15c3 3 7 3 10 0" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Empolgado</span>
    </div>

    <!-- 15. Solitário -->
    <div class="mood-item" data-mood="Solitario">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#9CA3AF"/>
                <circle cx="12" cy="10" r="1.6" fill="#000"/>
                <path d="M9 16h6" stroke="#000" stroke-width="2"/>
            </svg>
        </div>
        <span>Solitário</span>
    </div>

</div>


    <div id="selectedMood" class="selected-mood">Nenhum humor selecionado</div>

</div>

<script>
// =====================================================================
// SELECIONAR HUMOR + ANIMAÇÃO
// =====================================================================
document.querySelectorAll('.mood-item').forEach(item => {
    item.addEventListener('click', () => {
        const moodName = item.dataset.mood;
        document.getElementById("selectedMood").textContent =
            "Humor selecionado: " + moodName;

        // animação ao selecionar
        item.classList.add("selected");
        setTimeout(() => item.classList.remove("selected"), 300);
    });
});

// =====================================================================
// MODAL DE PERFIL
// =====================================================================
const modal = document.getElementById("profileModal");
const form = document.getElementById("profileForm");
const messageDiv = document.getElementById("formMessage");
const userNameNav = document.querySelector(".user-name");
const closeModalBtn = document.getElementById("closeModalBtn");

userNameNav.addEventListener("click", () => {
    modal.style.display = "block";
});

closeModalBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

// =====================================================================
// SUBMISSÃO DO PERFIL
// =====================================================================
form.addEventListener("submit", function(e){
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if(newPassword && newPassword !== confirmPassword){
        messageDiv.style.color = "red";
        messageDiv.textContent = "As senhas não coincidem!";
        return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("email", email);
    formData.append("newPassword", newPassword);
    formData.append("confirmPassword", confirmPassword);

    fetch("editar.php", { method: "POST", body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            messageDiv.style.color = "green";
            messageDiv.textContent = "Perfil atualizado com sucesso!";
            document.querySelector(".user-name").textContent = name;

            document.getElementById("email").value = email;

            setTimeout(() => modal.style.display = "none", 1000);
        } else {
            messageDiv.style.color = "red";
            messageDiv.textContent = data.message || "Erro ao atualizar perfil.";
        }
    })
    .catch(() => {
        messageDiv.style.color = "red";
        messageDiv.textContent = "Erro de conexão.";
    });
});

// =====================================================================
// FUNÇÃO GLOBAL PARA APLICAR O TEMA
// =====================================================================
function applyTheme({ 
    body, navbar, container, button, textColor, title, subtitle 
}) {
    document.body.style.background = body;
    document.querySelector(".navbar").style.background = navbar;

    document.querySelector(".container").style.background = container;

    const logout = document.querySelector(".logout-btn");
    logout.style.background = button.bg;
    logout.style.color = button.color;

    document.querySelector(".title").textContent = title;
    document.querySelector(".subtitle").textContent = subtitle;

    document.querySelectorAll(".title, .subtitle, .user-name")
        .forEach(el => el.style.color = textColor);
}

// Transições
document.body.style.transition = "all 0.6s ease";
document.querySelector(".navbar").style.transition = "all 0.6s ease";
document.querySelector(".logout-btn").style.transition = "all 0.6s ease";
document.querySelector(".container").style.transition = "all 0.6s ease";

// =====================================================================
// TEMAS DOS 15 HUMORES
// =====================================================================
const THEMES = {

    // Já existentes
    Feliz: {
        body: "linear-gradient(135deg, #FFF9C4, #FFE79A)",
        navbar: "linear-gradient(135deg, #FFE79A, #FFD56D)",
        container: "rgba(255, 247, 200, 0.45)",
        button: { bg: "#FFD56D", color: "#5C4200" },
        textColor: "#4A3B00",
        title: "Que bom te ver feliz! 😄",
        subtitle: "O MIRAGEM está brilhando com você!"
    },

    Triste: {
        body: "linear-gradient(135deg, #C4D7E0, #A9C6D9)",
        navbar: "linear-gradient(135deg, #A9C6D9, #8EB4CA)",
        container: "rgba(180, 205, 220, 0.45)",
        button: { bg: "#8EB4CA", color: "#082A3A" },
        textColor: "#0F2F3C",
        title: "Tudo bem ficar triste 💙",
        subtitle: "Respire. O MIRAGEM está com você."
    },

    Neutro: {
        body: "linear-gradient(135deg, #ECECEC, #DADADA)",
        navbar: "linear-gradient(135deg, #DADADA, #C7C7C7)",
        container: "rgba(230, 230, 230, 0.45)",
        button: { bg: "#C7C7C7", color: "#333" },
        textColor: "#333",
        title: "Um dia equilibrado 🌤️",
        subtitle: "Nada de mais, nada de menos."
    },

    Zangado: {
        body: "linear-gradient(135deg, #FFCECE, #FF9E9E)",
        navbar: "linear-gradient(135deg, #FF9E9E, #FF7B7B)",
        container: "rgba(255, 200, 200, 0.45)",
        button: { bg: "#FF7B7B", color: "#4A0000" },
        textColor: "#4A0000",
        title: "Respire… está tudo bem 😠",
        subtitle: "O MIRAGEM está aqui para te acalmar."
    },

    Apaixonado: {
        body: "linear-gradient(135deg, #FFD1DC, #FFB7CE)",
        navbar: "linear-gradient(135deg, #FFB7CE, #FF9AC2)",
        container: "rgba(255, 190, 210, 0.45)",
        button: { bg: "#FF9AC2", color: "#5B0025" },
        textColor: "#5B0025",
        title: "Amor está no ar 💗",
        subtitle: "O MIRAGEM vibra com você."
    },

    // Novos
    Ansioso: {
        body: "linear-gradient(135deg, #FFE7E7, #FFD1D1)",
        navbar: "linear-gradient(135deg, #FFD1D1, #FFBABA)",
        container: "rgba(255, 210, 210, 0.45)",
        button: { bg: "#FFBABA", color: "#600000" },
        textColor: "#600000",
        title: "Respira fundo... 😰",
        subtitle: "Vamos passar por isso juntos."
    },

    Cansado: {
        body: "linear-gradient(135deg, #E8E4F2, #D6D0E8)",
        navbar: "linear-gradient(135deg, #D6D0E8, #C1BADA)",
        container: "rgba(218, 213, 234, 0.45)",
        button: { bg: "#C1BADA", color: "#3A2F55" },
        textColor: "#3A2F55",
        title: "Você parece exausto 😴",
        subtitle: "Talvez seja hora de desacelerar."
    },

    Estressado: {
        body: "linear-gradient(135deg, #FFE2CC, #FFC7A8)",
        navbar: "linear-gradient(135deg, #FFC7A8, #FFB38C)",
        container: "rgba(255, 190, 150, 0.45)",
        button: { bg: "#FFB38C", color: "#5A2600" },
        textColor: "#5A2600",
        title: "Muita pressão hoje? 😣",
        subtitle: "Vamos deixar as coisas mais leves."
    },

    Surpreso: {
        body: "linear-gradient(135deg, #FFF2B8, #FFE88A)",
        navbar: "linear-gradient(135deg, #FFE88A, #FFD95A)",
        container: "rgba(255, 240, 170, 0.45)",
        button: { bg: "#FFD95A", color: "#5C4A00" },
        textColor: "#5C4A00",
        title: "Uau! 😮",
        subtitle: "Algo inesperado aconteceu?"
    },

    Motivado: {
        body: "linear-gradient(135deg, #D6FFDA, #A8F5B5)",
        navbar: "linear-gradient(135deg, #A8F5B5, #7DEB95)",
        container: "rgba(200, 255, 210, 0.45)",
        button: { bg: "#7DEB95", color: "#003D12" },
        textColor: "#003D12",
        title: "Vamos com tudo! 💪",
        subtitle: "Hoje é dia de conquistas."
    },

    Confuso: {
        body: "linear-gradient(135deg, #E3E5FF, #CACFFF)",
        navbar: "linear-gradient(135deg, #CACFFF, #B4BCFF)",
        container: "rgba(200, 210, 255, 0.45)",
        button: { bg: "#B4BCFF", color: "#1C2255" },
        textColor: "#1C2255",
        title: "Sentindo-se perdido? 🤔",
        subtitle: "Vamos clarear as ideias juntos."
    },

    Doente: {
        body: "linear-gradient(135deg, #D7F8E6, #B2EFD0)",
        navbar: "linear-gradient(135deg, #B2EFD0, #8DE6B9)",
        container: "rgba(180, 240, 210, 0.45)",
        button: { bg: "#8DE6B9", color: "#003D2A" },
        textColor: "#003D2A",
        title: "Se cuida, viu? 🤒",
        subtitle: "O MIRAGEM deseja melhoras."
    },

    Calmo: {
        body: "linear-gradient(135deg, #D9F6FF, #BEEBFA)",
        navbar: "linear-gradient(135deg, #BEEBFA, #A3E0F5)",
        container: "rgba(190, 240, 255, 0.45)",
        button: { bg: "#A3E0F5", color: "#003748" },
        textColor: "#003748",
        title: "Paz interior 🌿",
        subtitle: "A serenidade tomou conta."
    },

    Empolgado: {
        body: "linear-gradient(135deg, #FFE2FF, #FFB8FF)",
        navbar: "linear-gradient(135deg, #FFB8FF, #FF92FF)",
        container: "rgba(255, 200, 255, 0.45)",
        button: { bg: "#FF92FF", color: "#55004F" },
        textColor: "#55004F",
        title: "Vamos explodir energia! 🤩",
        subtitle: "Hoje você está imbatível."
    },

    Solitario: {
        body: "linear-gradient(135deg, #E5E5E5, #CCCCCC)",
        navbar: "linear-gradient(135deg, #CCCCCC, #B8B8B8)",
        container: "rgba(200, 200, 200, 0.45)",
        button: { bg: "#B8B8B8", color: "#3A3A3A" },
        textColor: "#3A3A3A",
        title: "Se sentindo sozinho? 🖤",
        subtitle: "Você nunca está sozinho aqui."
    }
};

// =====================================================================
// APLICAÇÃO DO TEMA AO CLICAR
// =====================================================================
document.querySelectorAll('.mood-item').forEach(item => {
    item.addEventListener('click', () => {

        const mood = item.dataset.mood;

        if (THEMES[mood]) {
            applyTheme(THEMES[mood]);
        }

    });
});

chatgpt
</script>

</body>
</html>
