<?php

require_once __DIR__ . 'db.php';


$sql = "
SELECT a.id, a.nome_completo, DATE_FORMAT(a.data_nascimento, '%d/%m/%Y') as data_nasc,
       a.municipio, a.categoria, c.nome as clube_nome
FROM atletas a
LEFT JOIN clubes c ON c.id = a.clube_id
ORDER BY a.data_registo DESC, a.id DESC
";
$res = $mysqli->query($sql);
$atletas = [];
while ($row = $res->fetch_assoc()) $atletas[] = $row;


$res2 = $mysqli->query("SELECT c.id, c.nome, c.municipio, COUNT(a.id) as ocupacao FROM clubes c LEFT JOIN atletas a ON a.clube_id = c.id GROUP BY c.id ORDER BY c.id");
$clubes = [];
while ($r = $res2->fetch_assoc()) $clubes[] = $r;
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8" />
  <title>Lista de Atletas</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="stylesheet" href="style.css">

</head>
<body>
  <h1>Atletas Cadastrados</h1>
  <p><a href="index.php">Novo Cadastro</a></p>

  <h2>Clubes (ocupação / 25)</h2>
  <div>
    <?php foreach($clubes as $c): ?>
      <div class="clube-card">
        <strong><?=htmlspecialchars($c['nome'])?></strong><br>
        <span class="small"><?=htmlspecialchars($c['municipio'])?></span><br>
        <span class="small">Ocupação: <?=intval($c['ocupacao'])?> / 25</span>
      </div>
    <?php endforeach; ?>
  </div>

  <h2>Lista de Atletas</h2>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Nome</th>
        <th>Data Nasc</th>
        <th>Idade</th>
        <th>Categoria</th>
        <th>Município</th>
        <th>Clube</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($atletas as $a): 
          $data = DateTime::createFromFormat('d/m/Y', $a['data_nasc']);
          $idade = $data ? (new DateTime())->diff($data)->y : '-';
      ?>
        <tr>
          <td><?=htmlspecialchars($a['id'])?></td>
          <td><?=htmlspecialchars($a['nome_completo'])?></td>
          <td><?=htmlspecialchars($a['data_nasc'])?></td>
          <td><?=htmlspecialchars($idade)?></td>
          <td><?=htmlspecialchars($a['categoria'])?></td>
          <td><?=htmlspecialchars($a['municipio'])?></td>
          <td><?=htmlspecialchars($a['clube_nome'] ?? '—')?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>
