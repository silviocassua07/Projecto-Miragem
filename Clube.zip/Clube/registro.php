<?php

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . 'db.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Requisição inválida.']);
    exit;
}

$nome = trim($input['nome_completo'] ?? '');
$data_nasc_str = trim($input['data_nascimento'] ?? '');
$municipio = trim($input['municipio'] ?? '');

if ($nome === '' || $data_nasc_str === '' || $municipio === '') {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Todos os campos são obrigatórios.']);
    exit;
}


$parts = explode('/', $data_nasc_str);
if (count($parts) !== 3) {
    echo json_encode(['success'=>false,'error'=>'Formato da data inválido. Use DD/MM/AAAA.']);
    exit;
}
list($d, $m, $y) = $parts;
if (!checkdate((int)$m, (int)$d, (int)$y)) {
    echo json_encode(['success'=>false,'error'=>'Data inválida.']);
    exit;
}
$data_nasc = sprintf('%04d-%02d-%02d', (int)$y, (int)$m, (int)$d);


function calcula_idade($data_nasc) {
    $nasc = new DateTime($data_nasc);
    $hoje = new DateTime('now');
    $diff = $hoje->diff($nasc);
    return (int)$diff->y;
}

$idade = calcula_idade($data_nasc);


if ($idade >= 7 && $idade <= 11) {
    $categoria = 'Infantil';
} elseif ($idade >= 12 && $idade <= 17) {
    $categoria = 'Júnior';
} elseif ($idade >= 18 && $idade <= 29) {
    $categoria = 'Sênior';
} else {
    echo json_encode(['success'=>false,'error'=>"Idade ($idade) fora das categorias aceitáveis."]);
    exit;
}

// Lógica de alocação:
// A) Tenta clube com municipio igual (e vagas < 25)
// B) Senão, primeiro clube com vagas < 25
// C) Senão, recusar

// 1) Procurar clube no mesmo município com vagas < 25
$stmt = $mysqli->prepare("
    SELECT c.id, COUNT(a.id) AS ocupacao
    FROM clubes c
    LEFT JOIN atletas a ON a.clube_id = c.id
    WHERE LOWER(c.municipio) = LOWER(?)
    GROUP BY c.id
    LIMIT 1
");
$stmt->bind_param('s', $municipio);
$stmt->execute();
$res = $stmt->get_result();
$clube_id = null;
$ocupacao = null;
if ($row = $res->fetch_assoc()) {
    if ((int)$row['ocupacao'] < 25) {
        $clube_id = (int)$row['id'];
    }
}
$stmt->close();

if (is_null($clube_id)) {

    $stmt2 = $mysqli->prepare("
        SELECT c.id, COUNT(a.id) AS ocupacao
        FROM clubes c
        LEFT JOIN atletas a ON a.clube_id = c.id
        GROUP BY c.id
        HAVING ocupacao < 25
        ORDER BY c.id ASC
        LIMIT 1
    ");
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    if ($row2 = $res2->fetch_assoc()) {
        $clube_id = (int)$row2['id'];
    }
    $stmt2->close();
}

// Se ainda null -> todos lotados
if (is_null($clube_id)) {
    echo json_encode(['success'=>false,'error'=>'Não há vagas disponíveis no momento']);
    exit;
}

// Inserir atleta com clube_id alocado
$insert = $mysqli->prepare("INSERT INTO atletas (nome_completo, data_nascimento, municipio, categoria, clube_id) VALUES (?,?,?,?,?)");
$insert->bind_param('ssssi', $nome, $data_nasc, $municipio, $categoria, $clube_id);
$ok = $insert->execute();
if (!$ok) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>'Erro ao inserir atleta: ' . $insert->error]);
    exit;
}

// retorno de sucesso
echo json_encode(['success'=>true,'message'=>'Atleta cadastrado com sucesso','clube_id'=>$clube_id,'categoria'=>$categoria]);
exit;
