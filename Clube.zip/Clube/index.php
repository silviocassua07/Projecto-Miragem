
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8" />
  <title>Cadastro de Atleta</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <style>
    body { font-family: Arial, sans-serif; max-width:700px; margin:30px auto; padding:0 10px; }
    label{display:block;margin-top:10px}
    input, select { width:100%; padding:8px; margin-top:4px; box-sizing:border-box; }
    button{margin-top:12px;padding:10px 16px;}
    .error{color:#b00020;}
    .success{color:green;}
  </style>
</head>
<body>
  <h1>Cadastro de Atleta</h1>
  <form id="cadForm">
    <label>Nome completo
      <input type="text" id="nome" required minlength="3" />
    </label>

    <label>Data de Nascimento (DD/MM/AAAA)
      <input type="text" id="data_nasc" placeholder="ex: 25/12/2008" pattern="\d{2}/\d{2}/\d{4}" required />
    </label>

    <label>Morada (Município)
      <input type="text" id="municipio" required />
    </label>

    <button type="submit">Cadastrar</button>
  </form>

  <div id="msg"></div>

<script>
document.getElementById('cadForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const nome = document.getElementById('nome').value.trim();
  const data_nasc = document.getElementById('data_nasc').value.trim();
  const municipio = document.getElementById('municipio').value.trim();

  const msgDiv = document.getElementById('msg');
  msgDiv.innerHTML = '';


  try {
    const res = await fetch('registro.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome_completo: nome, data_nascimento: data_nasc, municipio })
    });
    const json = await res.json();
    if (!json.success) {
      msgDiv.innerHTML = '<p class="error">' + (json.error || 'Erro desconhecido') + '</p>';
    } else {
      // sucesso -> redireciona para a página de tabelas
      // Guardar mensagem curta antes do redirect (opcional)
      window.location.href = 'atletas.php';
    }
  } catch (err) {
    console.error(err);
    msgDiv.innerHTML = '<p class="error">Erro de rede — tente novamente.</p>';
  }
});
</script>
</body>
</html>
